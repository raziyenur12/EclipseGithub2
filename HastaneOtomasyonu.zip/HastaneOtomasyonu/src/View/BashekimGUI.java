package View;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;

import Model.*;
import Model.Clinic;

import javax.swing.JLabel;
import javax.swing.JMenuItem;

import java.awt.Font;
import java.awt.Point;

import javax.swing.JButton;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;
import java.util.Iterator;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JSpinner;
import Helper.*;
import java.awt.Color;
import javax.swing.JComboBox;

public class BashekimGUI extends JFrame {

	//private static final long serialVersionUID = 1L;
	Clinic clinic =new Clinic();
	static Bashekim bashekim=new Bashekim();
	private JPanel w_pane;
	private JTextField fld_dName;
	private JTextField fld_dTcno;
	private JTextField fld_dPass;
	private JTextField fld_doctorID;
	private JTable table_doctor;
	private DefaultTableModel doctorModel=null;
	private Object[]doctorData=null;
	private JTextField fld_clinicName;
	private DefaultTableModel clinicModel=null;
	private Object[]clinicData=null;
	private JTable table_clinic;
	private JPopupMenu clinicMenu;
	private JTable table_worker;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BashekimGUI frame = new BashekimGUI(bashekim);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	/**
	 * Create the frame.
	 * @throws SQLException 
	 */
	public BashekimGUI(Bashekim bashekim) throws SQLException {
		//doktor model
		doctorModel=new DefaultTableModel();
		Object[]colDoctorName=new Object[4];
		colDoctorName[0]="ID";
		colDoctorName[1]="Ad Soyad";
		colDoctorName[2]="TC No";
		colDoctorName[3]="Şifre";
		doctorModel.setColumnIdentifiers(colDoctorName);
		doctorData=new Object[4];
		for(int i=0;i<bashekim.getDoctorList().size();i++) {
			doctorData[0]=bashekim.getDoctorList().get(i).getId();	
			doctorData[1]=bashekim.getDoctorList().get(i).getName();
			doctorData[2]=bashekim.getDoctorList().get(i).getTcno();
			doctorData[3]=bashekim.getDoctorList().get(i).getPassword();
			doctorModel.addRow(doctorData);
					}
	
		//Clinic Model
		clinicModel=new DefaultTableModel();
		Object[]colClinic=new Object[2];
		colClinic[0]="ID";
		colClinic[1]="Poliklinik Adı";
		clinicModel.setColumnIdentifiers(colClinic);
        clinicData=new Object[2];
        for(int i=0;i<clinic.getList().size();i++) {
        	clinicData[0]=clinic.getList().get(i).getId();
        	clinicData[1]=clinic.getList().get(i).getName();
        	clinicModel.addRow(clinicData);
        }
        //workermodel
        DefaultTableModel workerModel=new DefaultTableModel();
        Object[] colWorker =new Object[2];
        colWorker [0]="ID";
        colWorker[1]="Ad Soyad";
        workerModel.setColumnIdentifiers(colWorker);
        Object[] workerData =new Object[2];
        
        		
        		
        doctorModel.setColumnIdentifiers(colDoctorName);
		doctorData=new Object[4];
		for(int i=0;i<bashekim.getDoctorList().size();i++) {
			doctorData[0]=bashekim.getDoctorList().get(i).getId();	
			doctorData[1]=bashekim.getDoctorList().get(i).getName();
			doctorData[2]=bashekim.getDoctorList().get(i).getTcno();
			doctorData[3]=bashekim.getDoctorList().get(i).getPassword();
			doctorModel.addRow(doctorData);
					}
		setTitle("HASTANE YÖNETİM SİSTEMİ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 559, 457);
		w_pane = new JPanel();
		w_pane.setBackground(new Color(192, 192, 192));
		w_pane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(w_pane);
		w_pane.setLayout(null);
		
		JButton btnNewButton = new JButton("ÇIKIŞ YAP");
		btnNewButton.setBackground(new Color(255, 128, 192));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LoginGUI loginGUI=new LoginGUI();
				loginGUI.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(211, 17, 89, 23);
		w_pane.add(btnNewButton);
		
		JTabbedPane w_tabpane = new JTabbedPane(JTabbedPane.TOP);
		w_tabpane.setBounds(29, 71, 496, 313);
		w_pane.add(w_tabpane);
		
		JPanel w_doctor = new JPanel();
		w_doctor.setBackground(new Color(227, 155, 202));
		w_doctor.setToolTipText("");
		w_tabpane.addTab("Doktor Yönetimi", null, w_doctor, null);
		w_doctor.setLayout(null);
		
		fld_dName = new JTextField();
		fld_dName.setBounds(364, 42, 96, 19);
		w_doctor.add(fld_dName);
		fld_dName.setColumns(10);
		
		fld_dTcno = new JTextField();
		fld_dTcno.setBounds(364, 91, 96, 19);
		w_doctor.add(fld_dTcno);
		fld_dTcno.setColumns(10);
		
		fld_dPass = new JTextField();
		fld_dPass.setBounds(364, 144, 96, 19);
		w_doctor.add(fld_dPass);
		fld_dPass.setColumns(10);
		
		JLabel lblAdSoyad = new JLabel("Ad Soyad");
		lblAdSoyad.setBackground(new Color(227, 155, 202));
		lblAdSoyad.setBounds(364, 18, 131, 14);
		lblAdSoyad.setFont(new Font("Tahoma", Font.BOLD, 11));
		w_doctor.add(lblAdSoyad);
		
		JLabel lblTcNo = new JLabel("Tc No");
		lblTcNo.setBounds(364, 67, 131, 14);
		lblTcNo.setFont(new Font("Tahoma", Font.BOLD, 11));
		w_doctor.add(lblTcNo);
		
		JLabel lblifre = new JLabel("Şifre");
		lblifre.setBounds(364, 120, 131, 14);
		lblifre.setFont(new Font("Tahoma", Font.BOLD, 11));
		w_doctor.add(lblifre);
		
		JButton btn_addDoctor = new JButton("Ekle");
		btn_addDoctor.setBounds(364, 173, 85, 21);
		btn_addDoctor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(fld_dName.getText().length()==0 || fld_dPass.getText().length()==0||fld_dTcno.getText().length()==0) {
					Helper.showMsg("fill");
				}else {
					try {
						boolean control =bashekim.addDoctor(fld_dTcno.getText(),fld_dPass.getText(),fld_dName.getText());
						if(control) {
							Helper.showMsg("success");
							fld_dName.setText(null);
							fld_dTcno.setText(null);
							fld_dPass.setText(null);
							updateDoctorModel();						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				}
					
			}
		});
		btn_addDoctor.setFont(new Font("Verdana Pro Cond Semibold", Font.PLAIN, 12));
		w_doctor.add(btn_addDoctor);
		
		JLabel lblKullancId = new JLabel("KUllanıcı ID");
		lblKullancId.setBounds(364, 204, 131, 14);
		lblKullancId.setFont(new Font("Tahoma", Font.BOLD, 11));
		w_doctor.add(lblKullancId);
		
		fld_doctorID = new JTextField();
		fld_doctorID.setBounds(364, 222, 96, 19);
		w_doctor.add(fld_doctorID);
		fld_doctorID.setColumns(10);
		
		JButton btn_delDoctor = new JButton("Sil");
		btn_delDoctor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(fld_doctorID.getText().length()==0) {
					Helper.showMsg("Lütfen geçerli bir doktor seçiniz!");
				}else {
					if(Helper.confirm("sure")) {
						int selectID=Integer.parseInt(fld_doctorID.getText());
						try {
							boolean control=bashekim.deleteDoctor(selectID);
							if(control) {
								Helper.showMsg("success");
								updateDoctorModel();
							}
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					
				}
				}
			}
		});
		btn_delDoctor.setBounds(364, 251, 85, 21);
		btn_delDoctor.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		w_doctor.add(btn_delDoctor);
		
		JScrollPane w_scrollDoctor = new JScrollPane();
		w_scrollDoctor.setBounds(10, 10, 344, 262);
		w_doctor.add(w_scrollDoctor);
		
		table_doctor = new JTable(doctorModel);
		w_scrollDoctor.setViewportView(table_doctor);
		
		JPanel w_clinic = new JPanel();
		w_clinic.setBackground(new Color(255, 255, 255));
		w_tabpane.addTab("Poliklinikler", null, w_clinic, null);
		
		w_clinic.setLayout(null);
		
		JLabel lblPoliklinikAd = new JLabel("Poliklinik adı");
		lblPoliklinikAd.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblPoliklinikAd.setBounds(206, 21, 131, 14);
		w_clinic.add(lblPoliklinikAd);
		
		fld_clinicName = new JTextField();
		fld_clinicName.setColumns(10);
		fld_clinicName.setBounds(206, 44, 101, 19);
		w_clinic.add(fld_clinicName);
		
		JButton btn_addClinic = new JButton("Ekle");
		btn_addClinic.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(fld_clinicName.getText().length()==0) {
					Helper.showMsg("fill");
				}else {
					try {
						if(clinic.addClinic(fld_clinicName.getText())) {
							Helper.showMsg("başarılı!");
							fld_clinicName.setText(null);
							updateClinicModel();
						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
		btn_addClinic.setFont(new Font("Verdana Pro Cond Semibold", Font.PLAIN, 12));
		btn_addClinic.setBounds(206, 71, 100, 21);
		w_clinic.add(btn_addClinic);
		
		JScrollPane w_scrollWorker = new JScrollPane();
		w_scrollWorker.setBounds(308, 10, 173, 266);
		w_clinic.add(w_scrollWorker);
		
		table_worker = new JTable();
		w_scrollWorker.setViewportView(table_worker);
		
		JScrollPane w_scrollClinic = new JScrollPane();
		w_scrollClinic.setBounds(10, 10, 184, 266);
		w_clinic.add(w_scrollClinic);
		
		//MENÜÜÜÜ
		JPopupMenu clinicMenu = new JPopupMenu();
		JMenuItem updateMenu=new JMenuItem("Güncelle");
		JMenuItem deleteMenu=new JMenuItem("Sil");
		clinicMenu.add(updateMenu);
		clinicMenu.add(deleteMenu);
		
		
		updateMenu.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			int selID=Integer.parseInt(table_clinic.getValueAt(table_clinic.getSelectedRow(),0).toString());
			Clinic selectClinic=clinic.getFetch(selID);
			UpdateClinicGUI updateGUI= new UpdateClinicGUI(selectClinic);
			updateGUI.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			updateGUI.setVisible(true);
			updateGUI.addWindowListener(new WindowAdapter() {
				@Override
				public void windowClosed(WindowEvent e) {
					try {
						updateClinicModel();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});

			}
		});

		deleteMenu.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(Helper.confirm("sure")) {
int selID=Integer.parseInt(table_clinic.getValueAt(table_clinic.getSelectedRow(), 0).toString());
try {
	if(clinic.deleteClinic(selID)) {
		Helper.showMsg("başarılı");
		updateClinicModel();
	}else {
		Helper.showMsg("hata");
	}
} catch (SQLException e1) {
	e1.printStackTrace();
}
				}
			}
		});
		
		table_clinic = new JTable(clinicModel);
		table_clinic.setComponentPopupMenu(clinicMenu);
		table_clinic.addMouseListener(new MouseAdapter() {
			 @Override
			public void mousePressed(MouseEvent e) {
				Point point =e.getPoint();
				int selectedRow=table_clinic.rowAtPoint(point);
				table_clinic.setRowSelectionInterval(selectedRow, selectedRow);
			 }
		});
		w_scrollClinic.setViewportView(table_clinic);
		
		JComboBox select_doctor = new JComboBox();
		select_doctor.setBounds(206, 189, 101, 22);
		for(int i=0;i<bashekim.getDoctorList().size();i++) {
			select_doctor.addItem(new Item(bashekim.getDoctorList().get(i).getId(),bashekim.getDoctorList().get(i).getName()));
		}select_doctor.addActionListener(e ->{
			JComboBox c= (JComboBox) e.getSource();
			Item item=(Item) c.getSelectedItem();
			System.out.println(item.getKey()+":"+item.getValue());
		});
		w_clinic.add(select_doctor);
		
		JButton btn_addWorker = new JButton("Ekle");
		btn_addWorker.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int selRow=table_clinic.getSelectedRow();
				if(selRow>=0) {
				
				String selClinic=table_clinic.getModel().getValueAt(selRow, 0).toString();
				int selClinicID= Integer.parseInt(selClinic);
				Item doctorItem=(Item) select_doctor.getSelectedItem();
				try {
					boolean control=bashekim.addWorker(doctorItem.getKey(), selClinicID);
			if(control) {
				Helper.showMsg("Başarılı!");
				DefaultTableModel clearModel = (DefaultTableModel) table_worker.getModel();
				clearModel.setRowCount(0);
				for(int i =0;i<bashekim.getClinicDoctorList(selClinicID).size();i++){
					workerData[0]=	bashekim.getClinicDoctorList(selClinicID).get(i).getId();
					workerData[1]=	bashekim.getClinicDoctorList(selClinicID).get(i).getName();
					workerModel.addRow(workerData);
					}
				table_worker.setModel(workerModel);
			}else {
				Helper.showMsg("Hata!");
			}
				
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				}else {
					Helper.showMsg("Lütfen bir poliklinik seçiniz!");
				}
			}
		});
		btn_addWorker.setFont(new Font("Dialog", Font.PLAIN, 12));
		btn_addWorker.setBounds(207, 222, 100, 21);
		w_clinic.add(btn_addWorker);
		
		JLabel lblPoliklinikSe = new JLabel("Poliklinik Adı");
		lblPoliklinikSe.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblPoliklinikSe.setBounds(206, 118, 131, 14);
		w_clinic.add(lblPoliklinikSe);
		
		JButton btn_workerSelect = new JButton("Seç");
		btn_workerSelect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int selRow=table_clinic.getSelectedRow();
				if(selRow>=0) {
					String selClinic=table_clinic.getModel().getValueAt(selRow, 0).toString();
					int selClinicID= Integer.parseInt(selClinic);
					DefaultTableModel clearModel = (DefaultTableModel) table_worker.getModel();
					clearModel.setRowCount(0);
					try {
						for(int i =0;i<bashekim.getClinicDoctorList(selClinicID).size();i++){
						workerData[0]=	bashekim.getClinicDoctorList(selClinicID).get(i).getId();
						workerData[1]=	bashekim.getClinicDoctorList(selClinicID).get(i).getName();
						workerModel.addRow(workerData);
						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}table_worker.setModel(workerModel);
					
				}else {
					Helper.showMsg("Lütfen bir poliklinik seçiniz!");
				}
			}
		});
		btn_workerSelect.setFont(new Font("Dialog", Font.PLAIN, 12));
		btn_workerSelect.setBounds(206, 137, 100, 21);
		w_clinic.add(btn_workerSelect);
		table_doctor.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			
			@Override
			public void valueChanged(ListSelectionEvent e) {
try {
	fld_doctorID.setText(table_doctor.getValueAt(table_doctor.getSelectedRow(), 0).toString());
} catch (Exception ex) {
	// TODO: handle exception
                   }				
			}
		});
	
		
	  table_doctor.getModel().addTableModelListener(new TableModelListener() {
		
		@Override
		public void tableChanged(TableModelEvent e) {
			if(e.getType()==TableModelEvent.UPDATE) {
				int selectID=Integer.parseInt(table_doctor.getValueAt(table_doctor.getSelectedRow(), 0).toString());
				String selectName=table_doctor.getValueAt(table_doctor.getSelectedRow(), 1).toString();
				String selectTcno=table_doctor.getValueAt(table_doctor.getSelectedRow(), 2).toString();
				String selectPass=table_doctor.getValueAt(table_doctor.getSelectedRow(), 3).toString();
				
				try {
				boolean control=	bashekim.updateDoctor(selectID, selectTcno, selectPass, selectName);
			
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			
		}
	});
	
	

	}
		/*JLabel lblNewLabel = new JLabel("HOŞ GELDİNİZ,SAYIN"+bashekim.getName());{
		lblNewLabel.setBounds(29, 21, 131, 14);
		w_pane.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
	}*/
	public void updateDoctorModel() throws SQLException {
		DefaultTableModel clearModel=(DefaultTableModel) table_doctor.getModel();
		clearModel.setRowCount(0);
		for(int i=0;i<bashekim.getDoctorList().size();i++) {
			doctorData[0]=bashekim.getDoctorList().get(i).getId();	
			doctorData[1]=bashekim.getDoctorList().get(i).getName();
			doctorData[2]=bashekim.getDoctorList().get(i).getTcno();
			doctorData[3]=bashekim.getDoctorList().get(i).getPassword();
			doctorModel.addRow(doctorData);
					}
	}public void updateClinicModel() throws SQLException {
		DefaultTableModel clearmModel=(DefaultTableModel) table_clinic.getModel();
		clearmModel.setRowCount(0);
		for(int i=0;i<clinic.getList().size();i++) {
        	clinicData[0]=clinic.getList().get(i).getId();
        	clinicData[1]=clinic.getList().get(i).getName();
        	clinicModel.addRow(clinicData);
        }
	}
}