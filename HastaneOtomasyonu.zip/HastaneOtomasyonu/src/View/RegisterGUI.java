package View;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Helper.Helper;
import Model.Hasta;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class RegisterGUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel w_pane;
	private JTextField fld_name;
	private JTextField fld_tcno;
	private JTextField fld_pass;
	private Hasta hasta=new Hasta();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegisterGUI frame = new RegisterGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RegisterGUI() {
		setBackground(new Color(0, 128, 192));
		setTitle("HASTANE YÖNETİM SİSTEMİ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 292, 343);
		w_pane = new JPanel();
		w_pane.setBackground(new Color(0, 128, 192));
		w_pane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(w_pane);
		w_pane.setLayout(null);
		
		JLabel lblAdSoyad_1 = new JLabel("AD SOYAD:");
		lblAdSoyad_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblAdSoyad_1.setBounds(84, 11, 78, 14);
		w_pane.add(lblAdSoyad_1);
		
		fld_name = new JTextField();
		fld_name.setColumns(10);
		fld_name.setBounds(84, 36, 96, 19);
		w_pane.add(fld_name);
		
		JLabel lblTcNo_1 = new JLabel("T.C. NO:");
		lblTcNo_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblTcNo_1.setBounds(94, 66, 131, 14);
		w_pane.add(lblTcNo_1);
		
		fld_tcno = new JTextField();
		fld_tcno.setColumns(10);
		fld_tcno.setBounds(84, 91, 96, 19);
		w_pane.add(fld_tcno);
		
		JLabel lblifre = new JLabel("ŞİFRE:");
		lblifre.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblifre.setBounds(94, 121, 131, 14);
		w_pane.add(lblifre);
		
		fld_pass = new JTextField();
		fld_pass.setColumns(10);
		fld_pass.setBounds(84, 146, 96, 19);
		w_pane.add(fld_pass);
		
		JButton btn_register = new JButton("KAYIT OL");
		btn_register.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(fld_tcno.getText().length()==0|| fld_pass.getText().length()==0||fld_name.getText().length()==0) {
					Helper.showMsg("fill");
				}else {
					try {
						boolean control= hasta.register(fld_tcno.getText(),fld_pass.getText(),fld_name.getText());
					if(control) {
						Helper.showMsg("başarılı!");
						LoginGUI login=new LoginGUI();
						login.setVisible(true);
						dispose();
					}else {
						Helper.showMsg("hata");
					}
					
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					
					
				}
			}
		});
		btn_register.setBounds(94, 192, 89, 23);
		w_pane.add(btn_register);
		
		JButton btn_backto = new JButton("GİRİŞ YAP");
		btn_backto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LoginGUI login=new LoginGUI();
				login.setVisible(true);
				dispose();
			}
		});
		btn_backto.setBounds(91, 241, 89, 23);
		w_pane.add(btn_backto);
	}
}
